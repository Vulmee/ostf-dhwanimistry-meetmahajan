@echo off
echo Starting Personal Expense Tracker...
python -m pip install -r requirements.txt
python app.py
pause
