# Personal Expense Tracker - Python Flask + SQLite

A working tiny project for managing personal expenses.

## Technology
- Python 3
- Flask
- SQLite
- HTML5 / CSS3
- Jinja2 templates

## Features
- Dashboard with total expenses, current-month total, transaction count and average
- Category-wise spending visualization
- Recent expense list
- Add expense
- Edit expense
- Delete expense
- Search expenses
- Category filter
- SQLite persistent database
- Input validation and flash messages
- Responsive interface

## How to run on Windows

1. Install Python 3 if it is not installed.
2. Open this project folder in VS Code.
3. Open Terminal.
4. Run:
   `python -m venv venv`
5. Activate:
   `venv\Scripts\activate`
6. Install Flask:
   `pip install -r requirements.txt`
7. Start:
   `python app.py`
8. Open:
   `http://127.0.0.1:5000`

The SQLite database `expenses.db` is created automatically on first run with sample academic/demo data.

## Project structure

app.py                 Main Flask application
requirements.txt       Python dependency
templates/             Jinja2 HTML templates
static/style.css       CSS styling
README.md              Documentation
run.bat                Windows quick-start script

## Database
SQLite is used as the relational database. The `expenses` table stores:
id, expense_date, description, category, payment_method, amount.
