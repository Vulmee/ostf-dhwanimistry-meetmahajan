from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import date

app = Flask(__name__)
app.secret_key = "personal-expense-tracker-demo"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "expenses.db"

CATEGORIES = ["Food", "Transport", "Shopping", "Education", "Entertainment", "Health", "Bills", "Other"]
PAYMENTS = ["UPI", "Cash", "Debit Card", "Credit Card", "Net Banking"]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expense_date TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            payment_method TEXT NOT NULL,
            amount REAL NOT NULL CHECK(amount > 0)
        )
    """)
    count = conn.execute("SELECT COUNT(*) FROM expenses").fetchone()[0]
    if count == 0:
        sample = [
            ("2026-09-29", "Medicine", "Health", "UPI", 400),
            ("2026-09-28", "Hostel groceries", "Food", "UPI", 850),
            ("2026-09-27", "Auto / bus travel", "Transport", "Cash", 240),
            ("2026-09-25", "College stationery", "Education", "UPI", 430),
            ("2026-09-20", "Movie", "Entertainment", "Debit Card", 500),
            ("2026-09-18", "Online shopping", "Shopping", "Credit Card", 1250)
        ]
        conn.executemany("""
            INSERT INTO expenses
            (expense_date, description, category, payment_method, amount)
            VALUES (?, ?, ?, ?, ?)
        """, sample)
    conn.commit()
    conn.close()

def get_summary(conn):
    total = conn.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]
    month = date.today().strftime("%Y-%m")
    month_total = conn.execute(
        "SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(expense_date,1,7)=?",
        (month,)
    ).fetchone()[0]
    count = conn.execute("SELECT COUNT(*) FROM expenses").fetchone()[0]
    average = total / count if count else 0
    categories = conn.execute("""
        SELECT category, ROUND(SUM(amount),2) AS total
        FROM expenses
        GROUP BY category
        ORDER BY total DESC
    """).fetchall()
    return total, month_total, count, average, categories

@app.route("/")
def dashboard():
    conn = get_db()
    total, month_total, count, average, categories = get_summary(conn)
    recent = conn.execute("""
        SELECT * FROM expenses ORDER BY expense_date DESC, id DESC LIMIT 6
    """).fetchall()
    conn.close()
    max_category = max([float(x["total"]) for x in categories], default=1)
    return render_template(
        "dashboard.html",
        total=total, month_total=month_total, count=count, average=average,
        categories=categories, max_category=max_category, recent=recent
    )

@app.route("/expenses")
def expenses():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    conn = get_db()
    query = "SELECT * FROM expenses WHERE 1=1"
    params = []
    if q:
        query += " AND (description LIKE ? OR category LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    if category:
        query += " AND category=?"
        params.append(category)
    query += " ORDER BY expense_date DESC, id DESC"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return render_template("expenses.html", expenses=rows, categories=CATEGORIES, q=q, selected=category)

@app.route("/add", methods=["GET", "POST"])
def add_expense():
    if request.method == "POST":
        expense_date = request.form.get("expense_date", "")
        description = request.form.get("description", "").strip()
        category = request.form.get("category", "")
        payment = request.form.get("payment_method", "")
        amount = request.form.get("amount", "")
        try:
            value = float(amount)
            if value <= 0:
                raise ValueError
        except ValueError:
            flash("Please enter a valid positive amount.", "error")
            return render_template("form.html", mode="Add", expense=request.form,
                                   categories=CATEGORIES, payments=PAYMENTS)
        if not expense_date or not description or category not in CATEGORIES or payment not in PAYMENTS:
            flash("Please fill all fields correctly.", "error")
            return render_template("form.html", mode="Add", expense=request.form,
                                   categories=CATEGORIES, payments=PAYMENTS)
        conn = get_db()
        conn.execute("""
            INSERT INTO expenses (expense_date, description, category, payment_method, amount)
            VALUES (?, ?, ?, ?, ?)
        """, (expense_date, description, category, payment, value))
        conn.commit()
        conn.close()
        flash("Expense added successfully.", "success")
        return redirect(url_for("expenses"))
    return render_template("form.html", mode="Add", expense={"expense_date": date.today().isoformat()},
                           categories=CATEGORIES, payments=PAYMENTS)

@app.route("/edit/<int:expense_id>", methods=["GET", "POST"])
def edit_expense(expense_id):
    conn = get_db()
    existing = conn.execute("SELECT * FROM expenses WHERE id=?", (expense_id,)).fetchone()
    if not existing:
        conn.close()
        flash("Expense not found.", "error")
        return redirect(url_for("expenses"))
    if request.method == "POST":
        expense_date = request.form.get("expense_date", "")
        description = request.form.get("description", "").strip()
        category = request.form.get("category", "")
        payment = request.form.get("payment_method", "")
        amount = request.form.get("amount", "")
        try:
            value = float(amount)
            if value <= 0:
                raise ValueError
        except ValueError:
            flash("Please enter a valid positive amount.", "error")
            conn.close()
            return render_template("form.html", mode="Edit", expense=request.form,
                                   categories=CATEGORIES, payments=PAYMENTS)
        conn.execute("""
            UPDATE expenses
            SET expense_date=?, description=?, category=?, payment_method=?, amount=?
            WHERE id=?
        """, (expense_date, description, category, payment, value, expense_id))
        conn.commit()
        conn.close()
        flash("Expense updated successfully.", "success")
        return redirect(url_for("expenses"))
    conn.close()
    return render_template("form.html", mode="Edit", expense=existing,
                           categories=CATEGORIES, payments=PAYMENTS)

@app.post("/delete/<int:expense_id>")
def delete_expense(expense_id):
    conn = get_db()
    conn.execute("DELETE FROM expenses WHERE id=?", (expense_id,))
    conn.commit()
    conn.close()
    flash("Expense deleted successfully.", "success")
    return redirect(url_for("expenses"))

@app.route("/about")
def about():
    return render_template("about.html")

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
